package com.ejemplo.comedor

import android.graphics.*
import android.graphics.drawable.ColorDrawable
import android.view.*
import java.io.File
import android.graphics.pdf.PdfRenderer

class PdfView : View {
    private var renderer: PdfRenderer? = null
    private var pageIndex = 0
    private var bitmap: Bitmap? = null
    private var scale = 1f
    private var offsetX = 0f
    private var offsetY = 0f
    private var lastX = 0f
    private var lastY = 0f
    private var moving = false

    constructor(context: android.content.Context) : super(context) {
        setBackgroundColor(Color.rgb(217, 222, 227))
    }

    fun showPage(pdf: File, page: Int) {
        closeRenderer()
        val fd = android.os.ParcelFileDescriptor.open(pdf, android.os.ParcelFileDescriptor.MODE_READ_ONLY)
        renderer = PdfRenderer(fd)
        pageIndex = page.coerceIn(0, renderer!!.pageCount - 1)
        renderPage()
    }

    private fun renderPage() {
        val r = renderer ?: return
        val p = r.openPage(pageIndex)
        val w = (p.width * 2f).toInt()
        val h = (p.height * 2f).toInt()
        bitmap?.recycle()
        bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        bitmap!!.eraseColor(Color.WHITE)
        p.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
        p.close()
        scale = 1f
        offsetX = 0f
        offsetY = 0f
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val b = bitmap ?: return
        val vw = width.toFloat()
        val vh = height.toFloat()
        val fit = minOf(vw / b.width, vh / b.height)
        val s = fit * scale
        val left = (vw - b.width * s) / 2f + offsetX
        val top = (vh - b.height * s) / 2f + offsetY
        canvas.drawColor(Color.rgb(217, 222, 227))
        canvas.drawBitmap(b, null, RectF(left, top, left + b.width * s, top + b.height * s), Paint(Paint.FILTER_BITMAP_FLAG))
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x
                lastY = e.y
                moving = true
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                if (moving && e.pointerCount == 1) {
                    offsetX += e.x - lastX
                    offsetY += e.y - lastY
                    lastX = e.x
                    lastY = e.y
                    invalidate()
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                moving = false
                return true
            }
        }
        return true
    }

    fun closeRenderer() {
        renderer?.close()
        renderer = null
    }

    override fun onDetachedFromWindow() {
        closeRenderer()
        bitmap?.recycle()
        bitmap = null
        super.onDetachedFromWindow()
    }
}
