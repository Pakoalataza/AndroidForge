package com.ejemplo.comedor

import android.app.*
import android.os.*
import android.content.*
import android.graphics.*
import android.graphics.pdf.PdfRenderer
import android.print.*
import android.view.View
import android.widget.*
import java.io.*
import java.net.HttpURLConnection
import java.net.URL
import java.util.Calendar
import java.util.Locale

class MainActivity : Activity() {

    private lateinit var home: View
    private lateinit var viewerScreen: View
    private lateinit var pdfView: PdfView
    private lateinit var progress: ProgressBar
    private lateinit var error: TextView
    private lateinit var title: TextView
    private lateinit var monthSpinner: Spinner
    private lateinit var yearSpinner: Spinner

    private var child = "joel"
    private var currentFile: File? = null
    private var currentPage = 0

    private val months = arrayOf(
        "ENERO","FEBRERO","MARZO","ABRIL","MAYO","JUNIO",
        "JULIO","AGOSTO","SEPTIEMBRE","OCTUBRE","NOVIEMBRE","DICIEMBRE"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        home = findViewById(R.id.home)
        viewerScreen = findViewById(R.id.viewerScreen)
        pdfView = findViewById(R.id.pdfView)
        progress = findViewById(R.id.progress)
        error = findViewById(R.id.tvError)
        title = findViewById(R.id.tvTitle)
        monthSpinner = findViewById(R.id.monthSpinner)
        yearSpinner = findViewById(R.id.yearSpinner)

        val now = Calendar.getInstance()
        findViewById<TextView>(R.id.tvHomeMonth).text =
            "${months[now.get(Calendar.MONTH)]} ${now.get(Calendar.YEAR)}"

        findViewById<Button>(R.id.btnHomeJoel).setOnClickListener { openMenu("joel") }
        findViewById<Button>(R.id.btnHomeAitana).setOnClickListener { openMenu("aitana") }
        findViewById<Button>(R.id.btnBack).setOnClickListener {
            viewerScreen.visibility = View.GONE
            home.visibility = View.VISIBLE
        }
        findViewById<Button>(R.id.btnPrint).setOnClickListener { printCurrentPdf() }

        monthSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, months
        )

        val years = (now.get(Calendar.YEAR) - 1..now.get(Calendar.YEAR) + 1)
            .map { it.toString() }
        yearSpinner.adapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_dropdown_item, years
        )
        yearSpinner.setSelection(1)

        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: AdapterView<*>?) {}
            override fun onItemSelected(parent: AdapterView<*>?, view: View?, pos: Int, id: Long) {
                if (viewerScreen.visibility == View.VISIBLE) loadPdf()
            }
        }
        monthSpinner.onItemSelectedListener = listener
        yearSpinner.onItemSelectedListener = listener
        monthSpinner.setSelection(now.get(Calendar.MONTH))
    }

    private fun openMenu(which: String) {
        child = which
        home.visibility = View.GONE
        viewerScreen.visibility = View.VISIBLE
        title.text = if (child == "joel") "Joel" else "Aitana"
        loadPdf()
    }

    private fun makeUrl(): String {
        val monthNumber = monthSpinner.selectedItemPosition + 1
        val month = months[monthSpinner.selectedItemPosition]
        val year = yearSpinner.selectedItem.toString()

        val base =
            "https://site.educa.madrid.org/cp.juanfalco.valdemorillo/" +
            "wp-content/uploads/cp.juanfalco.valdemorillo/$year/" +
            String.format(Locale.US, "%02d", monthNumber) + "/"

        return if (child == "joel") {
            base + "ALERGIAS-$month-JUAN-FALCO-2.pdf"
        } else {
            base + "MENU-BASAL-$month-JUAN-FALCO.pdf"
        }
    }

    private fun wantedPage(): Int = if (child == "joel") 6 else 0

    private fun loadPdf() {
        error.visibility = View.GONE
        progress.visibility = View.VISIBLE
        currentFile = null

        val url = makeUrl()
        currentPage = wantedPage()

        Thread {
            try {
                val connection = URL(url).openConnection() as HttpURLConnection
                connection.connectTimeout = 15000
                connection.readTimeout = 30000
                connection.requestMethod = "GET"
                connection.instanceFollowRedirects = true
                connection.connect()

                if (connection.responseCode !in 200..299) {
                    throw IOException("HTTP ${connection.responseCode}")
                }

                val file = File(cacheDir, "menu_${child}.pdf")
                connection.inputStream.use { input ->
                    FileOutputStream(file).use { output -> input.copyTo(output) }
                }
                connection.disconnect()

                val check = PdfRenderer(
                    ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                )
                if (check.pageCount <= currentPage) {
                    check.close()
                    throw IOException("El PDF no contiene la página solicitada.")
                }
                check.close()

                currentFile = file

                runOnUiThread {
                    progress.visibility = View.GONE
                    pdfView.showPage(file, currentPage)
                }
            } catch (e: Exception) {
                runOnUiThread {
                    progress.visibility = View.GONE
                    error.text = "No se ha podido cargar el menú.\n\n${e.message ?: "Error de conexión"}"
                    error.visibility = View.VISIBLE
                }
            }
        }.start()
    }

    private fun printCurrentPdf() {
        val file = currentFile ?: return
        val manager = getSystemService(PRINT_SERVICE) as PrintManager
        manager.print(
            "Menu_${child.uppercase(Locale.US)}",
            PdfPrintAdapter(file, currentPage),
            PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                .build()
        )
    }

    private class PdfPrintAdapter(
        private val file: File,
        private val wantedPage: Int
    ) : PrintDocumentAdapter() {

        private var renderer: PdfRenderer? = null

        override fun onLayout(
            oldAttributes: PrintAttributes?,
            newAttributes: PrintAttributes,
            cancellationSignal: CancellationSignal,
            callback: LayoutResultCallback,
            extras: android.os.Bundle?
        ) {
            try {
                val fd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
                renderer = PdfRenderer(fd)
                callback.onLayoutFinished(
                    PrintDocumentInfo.Builder("menu.pdf")
                        .setContentType(PrintDocumentInfo.CONTENT_TYPE_DOCUMENT)
                        .setPageCount(1)
                        .build(),
                    true
                )
            } catch (e: Exception) {
                callback.onLayoutFailed(e.message)
            }
        }

        override fun onWrite(
            pages: Array<out PageRange>,
            destination: ParcelFileDescriptor,
            cancellationSignal: CancellationSignal,
            callback: WriteResultCallback
        ) {
            try {
                val r = renderer ?: throw IOException("PDF no abierto")
                val page = r.openPage(wantedPage)

                val width = 595
                val height = 842
                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                bitmap.eraseColor(Color.WHITE)

                val scale = minOf(
                    width.toFloat() / page.width,
                    height.toFloat() / page.height
                )
                val w = (page.width * scale).toInt()
                val h = (page.height * scale).toInt()
                val left = (width - w) / 2
                val top = (height - h) / 2

                val canvas = Canvas(bitmap)
                page.render(
                    bitmap,
                    Rect(left, top, left + w, top + h),
                    null,
                    PdfRenderer.Page.RENDER_MODE_FOR_PRINT
                )
                page.close()

                FileOutputStream(destination.fileDescriptor).use { out ->
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                }
                bitmap.recycle()
                callback.onWriteFinished(arrayOf(PageRange.ALL_PAGES))
            } catch (e: Exception) {
                callback.onWriteFailed(e.message)
            } finally {
                renderer?.close()
                renderer = null
            }
        }
    }
}
