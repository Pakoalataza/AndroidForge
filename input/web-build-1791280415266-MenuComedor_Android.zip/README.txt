MENU COMEDOR - proyecto Android

FUNCIONA SIN Google Docs Viewer ni WebView para el PDF.

- Al abrir: Joel / Aitana.
- Descarga el PDF directamente desde la web del colegio.
- Selecciona automáticamente el mes y año actuales.
- Permite cambiar mes/año.
- Joel abre la página 7 del PDF.
- Aitana abre la página 1.
- Rotación libre del teléfono.
- Botón Imprimir.
- No necesita permisos de almacenamiento.

COMPILACIÓN

1. Abrir esta carpeta en Android Studio.
2. Esperar a que Gradle termine.
3. Build > Build APK(s).
4. El APK aparecerá en:
   app/build/outputs/apk/debug/app-debug.apk

REQUISITO:
Android Studio con JDK 17.
